#ifndef POLYMULT_H

// p,q,r,d,tune1,tune2,tune3
void PolyMultGSQ(float*, float*, float*, long, long, long, long);
void PolyMultINQ(float*, float*, float*, long, long, long, long);
void PolyMultOPQ(float*, float*, float*, long, long, long, long);
void PolyMultBLQ(float*, float*, float*, long, long, long, long);
void PolyMultDCQ(float*, float*, float*, long, long, long, long); 
void PolyMultDCNew(float*, float*, float*, long, long, long, long); 

#endif
